package ejerciciosBuclesAvanzados;

import java.util.Scanner;

public class StartEjercicio08 {

	public static void main(String[] args) {

		Scanner teclado= new Scanner(System.in);
		
		System.out.print("�Cu�ntos n�meros de Fibonacci quieres?: ");
		int numero= teclado.nextInt();
		teclado.close();
		
		long fibonacci1=1, fibonacci2=1, fibonacci3=0;
		System.out.print(fibonacci1+" ");
		System.out.print(fibonacci2+" ");
		for(int i=1;i<=numero-2;i++) {
			fibonacci3=fibonacci1+fibonacci2;
			
			System.out.print(fibonacci3+" ");
			fibonacci1=fibonacci2;
			fibonacci2=fibonacci3;
		}
	}

}
