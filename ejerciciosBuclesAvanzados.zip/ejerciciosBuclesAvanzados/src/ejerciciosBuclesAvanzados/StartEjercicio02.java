package ejerciciosBuclesAvanzados;

import java.util.Scanner;

public class StartEjercicio02 {

	public static void main(String[] args) {

		Scanner teclado = new Scanner(System.in);
		int tramo = 1, totalMinutos = 0;

		System.out.println("Minutos del tramo n� " + tramo);
		int minutosTramo = teclado.nextInt();
		totalMinutos += minutosTramo;

		while (minutosTramo > 0) {
			tramo++;
			System.out.println("Minutos del tramo n� " + tramo);
			minutosTramo = teclado.nextInt();
			totalMinutos += minutosTramo;

		}
		teclado.close();
		System.out.println("Tiempo total de viaje: " + totalMinutos / 60 + " horas y " + totalMinutos % 60 + " minutos.");
	}

}
