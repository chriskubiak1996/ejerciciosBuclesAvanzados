package ejerciciosBuclesAvanzados;

public class StartEjercicio05 {

	public static void main(String[] args) {

		// Scanner teclado=new Scanner(System.in);

		System.out.print("Introduce puntaje: ");
		int puntaje = (int) (Math.random() * 12 + 1);// teclado.nextInt();
		// teclado.close();

		System.out.println(puntaje);
		int dado1 = 1, dado2 = 0, combinacion = 0;
		if (puntaje <= 6 && puntaje > 1) {
			dado2 = puntaje - 1;

			System.out.println("Dado 1|Dado 2");
			System.out.println("------|------");
			while (dado2 >= 1) {

				System.out.println(dado1 + "     |     " + dado2);
				dado1++;
				dado2--;
				combinacion++;
			}

		} else if (puntaje <= 12 && puntaje > 1) {
			dado2 = 6;
			dado1 = puntaje - 6;

			System.out.println("Dado 1|Dado 2");
			System.out.println("------|------");
			while (dado2 >= 1 && dado1 <= 6) {

				System.out.println(dado1 + "     |     " + dado2);
				dado1++;
				dado2--;
				combinacion++;
			}
		} else {

			System.out.println("El puntaje v�lido est� entre 2 y 12");
		}

		System.out.println("N�mero de combinaciones posibles: " + combinacion);

	}

}
