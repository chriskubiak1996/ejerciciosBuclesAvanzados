package ejerciciosBuclesAvanzados;

public class StartEjercicio03 {

	public static void main(String[] args) {

		long numero = (long) (Math.random() * 1999999999 + 1);

		System.out.println(numero);
		while (numero > 1) {
			if (numero % 2 == 0) {
				numero /= 2;
			} else {
				numero *= 3;
				numero++;
			}

			System.out.println(numero);
		}
	}

}
