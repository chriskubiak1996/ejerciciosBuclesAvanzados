package ejerciciosBuclesAvanzados;

public class StartEjercicio04 {

	public static void main(String[] args) {

		long numeroInicial = (long) (Math.random() * 1999999999 + 1), numero1 = numeroInicial, numero2 = 0;

		System.out.println("N�mero " + numeroInicial);
		while (numero1 > 1) {
			if (numero1 % 2 == 0) {
				numero1 /= 2;
			} else {
				numero1 *= 3;
				numero1++;
			}
			numero2 = numero1;
			if (numero2 < numeroInicial) {
				
				System.out.print("*");
				while (numero2 > 1) {
					if (numero2 % 2 == 0) {
						numero2 /= 2;
					} else {
						numero2 *= 3;
						numero2++;
					}

					System.out.print("*");
				}
				
				System.out.println();
			}
		}
	}

}
