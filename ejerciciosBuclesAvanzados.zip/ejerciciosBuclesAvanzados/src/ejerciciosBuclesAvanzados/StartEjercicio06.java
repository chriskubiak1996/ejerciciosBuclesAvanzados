package ejerciciosBuclesAvanzados;

import java.util.Scanner;

public class StartEjercicio06 {

	public static void main(String[] args) {

		Scanner teclado = new Scanner(System.in);

		System.out.println("Ingrese varios valores, termine con cero:");
		int numero = 1, positivo = 0, negativo = 0;
		while (numero != 0) {

			numero = teclado.nextInt();
			if (numero > 0) {
				positivo++;
			}
			if (numero < 0) {
				negativo++;
			}
		}
		teclado.close();

		System.out.print("Positivos: ");
		for (int i = 1; i <= positivo; i++) {

			System.out.print("*");
		}

		System.out.println();
		System.out.print("Negativos: ");
		for (int i = 1; i <= negativo; i++) {

			System.out.print("*");
		}
	}

}
